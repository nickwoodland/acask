<h4>News Archive</h4>
<ul>
	<?php wp_get_archives(); ?>
</ul>